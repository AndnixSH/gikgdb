Before you use '/ART Debug/Server/Login (USB/WIFI)', you should install
$(GIKDBG.ART)/artserver/gikdbg.apk first !!!

How to install gikdbg.apk ?
Recommended Way : use '/ART Debug/Server/ADB Device --> Login' to auto install;

Note:	If gikdbg.apk can't execute 'su' command and cause gikdbg.art
	unable to debug any app, then you can use 
		"/data/data/com.gikir.gikdbg/lib/libgikir_server_exe.so"  (DVM)
		"/data/app-lib/com.gikir.gikdbg-1/libgikir_server_pie.so" (ART)
	(it's a strange named elf executable file) in adb command line.