You must install gikir_iserver.deb to your iDevice before you use gikdbg.

/*-*****----- The Way to Install 'gikir_iserver.deb' -----*****-*/

Method 1.

step 1. In your PC, install iFunxbox;
step 2. upload 'gikir_iserver.deb' to /var/root/Media/CyDia/AutoInstall from iFunxbox;
step 3. restart your iDevice.

Method 2.

step 1. In your iDevice, install openssh from Cydia;
step 2. In your PC, install PuTTY;
step 3. In your PC, install openssh;
step 4. scp 'gikir_iserver.deb' from command line in PC to /var/tmp;
step 4. dpkg -i /var/tmp/gikir_iserver.deb from command line in PuTTY.

Method 3.

step 1. Add source 'http://apt.feng.com/geekneo' in Cydia;
step 2. In Cydia, search 'gikir_iserver' to install.


