How to debug helloworld:

Method 1. 

1.Compile helloworld.c to helloworld;

2.Start gikir_iserver in your iDevice;

3.Start gikdbg.exe and /iDebug/Login with USB or WIFI to your iDevice;

4.Execute /iDebug/View/iShell to active the gikir shell;

5.In the shell, execute the following command:

	$upload /usr/bin/helloworld

then select the helloworld to upload;

6.In the shell, execute the following command:

	chmod 755 /usr/bin/helloworld;

7.Execute /iDebug/File/Open to select '/usr/bin/helloworld' to debug;

8.Have fun ...



Method 2.

1.Compile helloworld.c to helloworld;

2.Start gikir_iserver in your iDevice;

3.Start gikdbg.exe and /iDebug/Login with USB or WIFI to your iDevice;

4.Write a ishell script helloworld.ish;

5.Execute /iDebug/View/iShell to active the gikir shell;

6.Right click your mouse to invoke the menu, execute 'Load shell script'
  to select helloworld.ish;

7.Have fun ...